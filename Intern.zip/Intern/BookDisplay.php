<!DOCTYPE html>
<html>
<head>
<script>
    function myfunc() {
         window.location.href="/Intern/searchbox1.html";
}
</script>
<style>

body
{  background-color:#F5F5F5;

}
 
  

  #bookimage .img{
       display:block;
       margin-left:2%;
       margin-top:-30%;
       height:800px;
       width:500px;
       
  }
 .button
{ 
position:absolute;
bottom:-25%;
margin-left:55%;
border:none;
margin-top:70%;


}
.button input[type="submit"]{
     border-style:none;
     background-color:inherit;
     font-size:33px;
    font-weight:bold;
     text-align:center;
     margin-left:13%;

}
.button
{ height:70px;
width:200px;
font-size:35px;
     margin-top:-80%;

background: linear-gradient(135deg, #6e8efb, #a777e3);
		border-radius: 4px;
		transition: box-shadow .5s ease, transform .2s ease;
box-shadow: 0 5px 15px rgba(0, 0, 0, .3);
font-weight: bold;
}
.button1
{ height:70px;
width:200px;
font-size:30px;
background: linear-gradient(135deg, #6e8efb, #a777e3);
		border-radius: 4px;
		transition: box-shadow .5s ease, transform .2s ease;
box-shadow: 0 5px 15px rgba(0, 0, 0, .3);
font-weight: bold;

}
.button1 button{
border-style:none;
background-color:inherit;
font-size:33px;
display:block;
 width: 250px;
    height: 50px;
    margin: 0 auto;
margin-left:-12%;
margin-top:7%;
font-weight:bold;
verical-align:middle;

}
  .title{
                background-color:#1A1A1D;
                height:200px;
                width:100%;
                font-family: "Lobster", serif; 
                position:absolute; 
                top:0%;     
                left:0%;  
          }
         .title label{
              position:absolute; 
              font-size:50px;
              color:#E3E2DF;
              top:30%;   
              left:3%;
         }
         .title p{
               position:absolute; 
              color:#E3E2DF;
              top:45%;
              left:4%;
         }
         .title a{
                color:white;
               font-size:30px;
        }
  #card{
       height:800px;
       max-width:450px;
       margin-left:75%;
       margin-top:-35%;
       background-color:grey;
       border-radius:10px;
  }
  #card .sellerimg img{
     height:350px;
     width:100%;
     margin:auto;
  }
 #card .sellerinfo {
     background-color:#d8d8d8;
     font-family:sans-serrif;
     font-size:30px;
     height:400px;width:449px;  
  }
 .sellerinfo p{
      position:relative;
      top:6%;
      text-align:center;
  }
 .bookinfo {
     width:40%;
     position:relative;
     font-style:oblique;
     background-color:#ffe9ec;
     border-radius:10px;
      border: 1px solid black;
     padding-left:25px;
     top:250px;
     margin-left:auto;
   margin-right:auto;
   
     
  }

	

</style>
</head>
<body>
<div class='title'>
<a href="searchbox1.php">HOME</a>
<label>TOKOBUKU</label>
<p>The right book will always keep you company</p>
</div>

<div class="bookinfo">
<?php
session_start();
$Bookid="";

$Bookid=$_GET['Bookid'];

/*if(isset(Bookid)
{
$Bookid=$_GET['bookid'];
}*/
$_SESSION['bookid']=$Bookid;


$conn=new mysqli("localhost","root","akshara08","Intern");
if($conn)
{
$statement="select Bookname,sellerid,Author,Genre,Edition,Price,Description from books1 where Bookid='$Bookid'";
$result=mysqli_query($conn,$statement);
if($result)
{
  $row=mysqli_fetch_assoc($result);
           $_SESSION['sellerid']=$row["sellerid"];
           echo "<br><h1> <label>BOOKNAME : </label>".$row["Bookname"]."</h1> <br>";
           echo "<h1><label>AUTHOR : </label>".$row["Author"]."</h1><br>";
           echo  "<h1><label>GENRE : </label>".$row["Genre"]."</h1><br>";     
           echo  "<h1><label>EDITION : </label>".$row["Edition"]."</h1><br>";     
           echo  "<h1><label>PRICE : </label>".$row["Price"]."</h1><br>";     
           echo  "<h1><label>DESCRIPTION : </label>".$row["Description"]."</h1><br>";          
              
       
      
}
else 
{
  echo "error in mysqli query";
}
}
else
{echo "not connected";
}

?>
</div>
<form action="/Intern/orders.php">
<div class="button">
<input type="submit" value="BUY" />
</div>
</form>



<div id="bookimage">
<?php
$bookid=$_SESSION['bookid'];
$statement1="select Image from bookimage where Bookid='$bookid'";
$result1=mysqli_query($conn,$statement1);
$row=mysqli_fetch_assoc($result1);
$image=$row['Image'];
echo "<img class='img' src='/images/$image'/>"; 
?>
</div>
<div id="card">
<div class="sellerimg">
<?php
 $sellerid=$_SESSION['sellerid'];
 $sellerimg="";
 $Bookid=$_SESSION['bookid'];
 $conn=new mysqli("localhost","root","akshara08","Intern");
 $statement2="select image from image where userid='$sellerid'";
 $result2=mysqli_query($conn,$statement2);
if($result2)
{  
    $row=mysqli_fetch_assoc($result2);
     $image=$row["image"];
    echo "<img class='img' src='/userimages/$image'/>";

}
else
{echo "error";
}
?>
</div>
<div class="sellerinfo">
<?php

$Sellerid="";
$bookid=$_SESSION['bookid'];
$conn=new mysqli("localhost","root","akshara08","Intern");
if($conn)
{ 
$statement="select Firstname,phone from USERS where userid='$sellerid'";
$result=mysqli_query($conn,$statement);
if($result)
{    
  $row=mysqli_fetch_assoc($result);
            
           echo "<p>".$row["Firstname"]. "</p>";
           echo "<p>" .$row["ContactAddress"]."</p>";
           echo  "<p>".$row["phone"]."</p>";     
                  
}
else 
{
  echo "error in mysqli query";
}
}
?>
</div>
</div>

</body>
</html>
