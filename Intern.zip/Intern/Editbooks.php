<?php
session_start();
  $conn=new mysqli('localhost','root','akshara08','Intern');
  $sql="select * from books1 where Bookid=".$_GET['Bookid'];
   $_SESSION['bookid']=$_GET['Bookid'];
  $res=mysqli_query($conn,$sql);
  $sql1="select Image from bookimage where Bookid=".$_GET['Bookid'];
   $res1=mysqli_query($conn,$sql1);
  $row=mysqli_fetch_assoc($res);
   $row1=mysqli_fetch_assoc($res1);
     $Image=$row1['Image'];
   $Bookname=$row['Bookname'];
   $Author=$row['Author'];
   $Genre=$row['Genre'];
   $Edition=$row['Edition'];
   $Price=$row['Price'];
   $Desc=$row['Description'];
?>
<!DOCTYPE html>
<html>
<head>
<style>
             html,body{
                             width:100%;
                             height:100%;
                             
                             background-repeat:no-repeat;                   
                    } 
             
          #menu 
                { background-color:SlateBlue;
                   position:absolute;
                   height:100%;
                   width:300px;
                    left:-5px;
                    z-index:99;
                    transition:all 500ms linear;
                }  
              #menu ul li
                {    
                      list-style-type: none;
                      font-size:25px;
                      padding:10px;
                      margin:30px 5px;
                      border-bottom:1px solid white;
                }
              img{
                   height:400px;
                   width:700px;
                   margin-left:auto;
                   margin-right:auto; 
              }
            .profilecard{
                   height:950px;
                   width:700px;
                   display:block;
                   border:1px black solid;
                  position:relative;
                  top:0%;
                  left:30%;
              }
          .userdetails{
                    display:block;
                    background-color:white;  
                    font-family:sans-seriff;
                    font-size:30px; 
                    height:400px;
                    width:700px;
                   color:black;
             }
        .edit{
                  text-align:center;
                 color:white;
                 background-color:black;
                 font-family:sans-seriff;
                 font-size:35px; 
           }
       a { 
             text-decoration:none;
             color:white;
        }
     a:hover {
        color:#d8d8d8;
      }
    .welcome{
         text-align:center;
         color:white;
        font-size:25px;
        font-family:sans-seriff Bold;
     }
    input[type="submit"] {
          background-color:black;
          border:none;
          color:white;
          font-size:25px;
          position:relative;
          bottom:0%;
     }

  input[type='file']
        {
           
     }
</style>
</head>
<body>
    <div id="menu">
                 
                  <ul> 
                        
                        <li><a href=#>Editprofile</a></li>
                        <li><a href=Myordersdisplay.php>Myorders</a></li>
                        <li><a href=ResponsesDisplay.php>Response</a></li>
                        <li><a href=Uploads.php>Uploads</a></li>
                        <li><a href=Logout.php>Logout</a></li>
                     
                  </ul>
 </div>

<div class="profilecard">
       <div class='userdetails'>
      
        <form method='POST' action='/Intern/updatebooks.php'  enctype="multipart/form-data">
       <?php 
       echo  "<div>"; 
      echo "<img src='/images/$Image'>";
      echo  "<input type='file'  name='profile'  value='Edit' />";  
      echo  "</div>";
       echo  "<label> BookName: </label><br>";
       echo  "<input  type='text'  name='Bookname'  value='$Bookname' /><br>"; 
       echo  "<label> Author: </label><br>";
       echo  "<input  type='text' name='Author' value='$Author'/><br>";
       echo   "<label>Genre: </label><br>";
       echo  "<input  type='text' name='Genre'  value='$Genre' /><br>";
       echo  "<label> Edition: </label><br>" ;
       echo  "<input  type='text' name='Edition'  value='$Edition '/><br>";
       echo  "<label> Price: </label><br>" ;
       echo  "<input  type='text' name='Price'  value='$Price '/><br>";
       echo  "<label> Description: </label><br>" ;
       echo  "<textarea rows='1' cols='40'   name='Desc'  >".$Desc."</textarea><br><br>";
       echo  "<div class='edit'>";
       echo  "<input  type='submit' name='update'  value='UPDATE' /><br>";
       echo "</div>";
      ?>
       </form>
       </div>  
</div>
</body>
</html>
