<!Doctype html>
<html>
<body>
<script>
  alert("Do you want to logout?");
</script>
<?php
  session_start();
  $_SESSION['userid']="";
  header("Location:http://localhost/Intern/welcome.php");
?>
</body>
</html>
