<!DOCTYPE html>
<html>
<head>
  <style>
                  html,body{
                             width:100%;
                             height:100%;
                             background-color:#dcdcdc;
                             background-repeat:no-repeat;
                                     
                    } 
             
             
            #menu 
                {
                   position:absolute;
                   top:250px;
                   height:85%;
                   width:300px;
                    left:-5px;
                    z-index:99;
                     background-color:#B23850;
                    transition:all 500ms linear;
                }  
              #menu ul li
                {    
                      list-style-type: none;
                      font-size:25px;
                      padding:10px;
                      margin:30px 5px;
                      border-bottom:1px solid white;
                }
              .title{
                background-color:#1A1A1D;
                height:250px;
                width:100%;
                font-family: "Lobster", serif; 
                position:absolute; 
                top:0%;     
                left:0%;  
          }
         .title label{
              position:absolute; 
              font-size:50px;
              color:#E3E2DF;
              top:30%;   
              left:3%;
         }
         .title p{
               position:absolute; 
              color:#E3E2DF;
              top:45%;
              left:4%;
         }
                 table, td, th {  
  border: 1px solid #ddd;
  text-align: left;
}

table {
 position:relative;
  top:250px;
  border-collapse: collapse;
  width: 100%;

}
                 th, td {
                     padding: 15px;
                     text-align: left; 
                }
              a { 
             text-decoration:none;
             color:white;
        }
     a:hover {
        color:#d8d8d8;
      }
       .bookspace {
             width:500px;
             position:relative;
             left:35%;
             
        }
       img{
            height:100px;
            width:100px;
            padding:10px;
    }
      label {
            color:red;
    }
  </style>
</head>
<body>
<div class='title'>
<label>TOKOBUKU</label>
<p>The right book will always keep you company</p>
</div>
    <div id="menu">
                 
                  <ul> 
                         <li><a href=searchbox1.php>Home</a></li>
                        <li><a href=Profile.php>Editprofile</a></li>
                        <li><a href=Myordersdisplay.php>Myorders</a></li>
                        <li><a href=ResponsesDisplay.php>Response</a></li>
                        <li><a href=Uploads.php>Uploads</a></li>
                        <li><a href=Logout.php>Logout</a></li>
                     
                  </ul>
 </div>
<div class="bookspace">
  <table border='1' >
      <tr>     
                    <th>Orderid</th>
                  <th>Bookimage</th>
                  <th>Bookname</th>
                      <th>Price</th>
                     <th>Status</th>
          </tr> 
  <?php
  include('myorders.php');
                 while($row=mysqli_fetch_assoc($result))
                {      
                        echo "<div class='books'>";           
                        $bookid=$row['bookid'];
                        $sql1="select Image from bookimage where Bookid='$bookid'"; 
                       $result1=mysqli_query($conn,$sql1);
                       if($result1)
                       $row1=mysqli_fetch_assoc($result1);
                       $Image=$row1['Image'];
                       echo  "<tr>";
                       echo "<td>".$row['Refno']."</td>";
                       echo  "<td><img src='http://".$_SERVER['SERVER_NAME']. "/images/".$row1['Image']. "'/></td>";
                       $Bookname=$row['BookName'];
                       echo   "<td>".$Bookname."</td>";
                       $Price=$row['Price'];
                       echo   "<td>".$Price."</td>"; 
                        $status=$row['status'];
                        echo  "<td>".$status."</td>";
                        echo  "<td><button onClick=myfun(".$bookid.")>view details</button></td>";
                       echo "</div>";
                 }            
   ?>
</table>
</div>
</body>
<script>
         function myfun(id)
           {  
                    window.location.href="/Intern/showdet.php?Bookid="+id;
           } 
</script>
</html>
