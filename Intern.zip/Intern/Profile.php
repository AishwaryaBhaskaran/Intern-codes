<?php
 session_start();
  if(empty($_SESSION['userid'])) 
   {  
          header("Location:http://localhost/Intern/welcome.php");
   }
?>
<!DOCTYPE html>
<html>
<head>
<style>
             html,body{
                             width:100%;
                             height:100%;
                             background-color:#dcdcdc;
                             background-repeat:no-repeat;
                             overflow-x: hidden;  
                             overflow-y: hidden ;                     
                    } 
             
          #menu 
                {
                   position:absolute;
                   top:250px;
                   height:85%;
                   width:300px;
                    left:-5px;
                    z-index:99;
                     background-color:#B23850;
                    transition:all 500ms linear;
                }  
              #menu ul li
                {    
                      list-style-type: none;
                      font-size:25px;
                      padding:10px;
                      margin:30px 5px;
                      border-bottom:1px solid white;
                }
              img{
                   height:400px;
                   width:700px;
                   margin-left:auto;
                   margin-right:auto; 
              }
            .profilecard{
                   height:800px;
                   width:700px;
                   display:block;
                   border:1px black solid;
                  position:relative;
                  top:0%;
                  left:30%;
              }
.title{
                background-color:#1A1A1D;
                height:250px;
                width:100%;
                font-family: "Lobster", serif; 
                position:absolute; 
                top:0%;     
                left:0%;  
          }
         .title label{
              position:absolute; 
              font-size:50px;
              color:#E3E2DF;
              top:30%;   
              left:3%;
         }
         .title p{
               position:absolute; 
              color:#E3E2DF;
              top:45%;
              left:4%;
         }
          .userdetails{
                    display:block;
                    background-color:white;  
                    font-family:sans-seriff;
                    font-size:30px; 
                    height:400px;
                    width:700px;
                   color:black;
             }
        .edit{
                  text-align:center;
                 color:white;
                 background-color:black;
                 font-family:sans-seriff;
                 font-size:35px; 
           }
       a { 
             text-decoration:none;
             color:white;
        }
     a:hover {
        color:#d8d8d8;
      }
    .welcome{
         text-align:center;
         color:white;
        font-size:25px;
        font-family:sans-seriff Bold;
     }
    input[type="submit"] {
          background-color:black;
          border:none;
          color:white;
          font-size:25px;
     }
  textarea {
            
           font-size:15px;
           width:500px;
           border-top:0px;
           border-left:0px;
           border-right:0px;
           border-bottom:1px black solid;
     }
  input[type='file']
        {
           
     }
</style>
</head>
<body>
<div class='title'>
<label>TOKOBUKU</label>
<p>The right book will always keep you company</p>
</div>
    <div id="menu">
                 
                  <ul> 
                         <li><a href=searchbox1.php>Home</a></li>
                        <li><a href=#>Editprofile</a></li>
                        <li><a href=Myordersdisplay.php>Myorders</a></li>
                        <li><a href=ResponsesDisplay.php>Response</a></li>
                        <li><a href=Uploads.php>Uploads</a></li>
                        <li><a href=Logout.php>Logout</a></li>
                     
                  </ul>
 </div>
<div class="welcome">
<?php
include('userprofile.php');
echo "<p>Hey" . $Firstname . ".Hope you are doing great!!</p>";
?>
</div>
<div class="profilecard">
<?php 

     
 ?>  
       <div class='userdetails'>
      
        <form method='POST' action='/Intern/update.php'  enctype="multipart/form-data">
       <?php 
        include('userprofile.php');
      
       echo  "<div>"; 
      echo "<img src='/userimages/$image'>";
      echo  "<input type='file'  name='profile'  value='Edit' />";  
	
      echo  "</div>";
       echo  "<label> FirstName: </label><br>";
       echo  "<input  type='text'  name='firstname'  value='$Firstname' /><br>"; 
       echo  "<label> Lastname: </label><br>";
       echo  "<input  type='text' name='Lastname' value='$Lastname'/><br>";
       echo   "<label> Email: </label><br>";
       echo  "<input  type='text' name='useremail'  value='$useremail ' disabled /><br>";
       echo  "<label> Phone: </label><br>" ;
       echo  "<input  type='text' name='phone'  value='$phone '/><br>";
       echo  "<div class='edit'>";
       echo  "<input  type='submit' name='update'  value='UPDATE' /><br>";
       echo "</div>";
      ?>
       </form>
       </div>  
</div>
</body>
</html>
