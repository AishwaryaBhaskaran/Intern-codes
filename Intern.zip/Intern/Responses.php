<?php
ini_set('display_errors','1');
session_start();
$username=$phone=$BookName=$Author=$Genre=$Edition=$Price="";
$userid=$_SESSION['userid'];
$conn=new mysqli('localhost','root','akshara08','Intern');
$sql="select  * from orders where sellerid='$userid'";
$result=mysqli_query($conn,$sql);
?>
