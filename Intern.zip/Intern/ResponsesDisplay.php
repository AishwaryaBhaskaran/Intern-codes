
<!DOCTYPE html>
<html>
<head>
 <style>
                          html,body{
                             width:100%;
                             height:100%;
                             background-repeat:no-repeat;                  
                    } 
              #menu 
                {
                   position:absolute;
                   top:250px;
                   height:85%;
                   width:300px;
                    left:-5px;
                    z-index:99;
                     background-color:#B23850;
                    transition:all 500ms linear;
                }  
        
              #menu ul li
                {    
                      list-style-type: none;
                      font-size:25px;
                      padding:10px;
                      margin:30px 5px;
                      border-bottom:1px solid white;
                }
               .title{
                background-color:#1A1A1D;
                height:250px;
                width:100%;
                font-family: "Lobster", serif; 
                position:absolute; 
                top:0%;     
                left:0%;  
          }
         .title label{
              position:absolute; 
              font-size:50px;
              color:#E3E2DF;
              top:30%;   
              left:3%;
         }
         .title p{
               position:absolute; 
              color:#E3E2DF;
              top:45%;
              left:4%;
         }
              a { 
             text-decoration:none;
             color:white;
        }
     a:hover {
        color:#d8d8d8;
      }
                      table, td, th {  
  border: 1px solid #ddd;
  text-align: left;
}

table {
  border-collapse: collapse;
  width: 100%;

}
                 th, td {
                     padding: 15px;
                     text-align: left; 
                }
     .tab{
             width:700px;
             position:relative;
             left:30%;
         top:350px;
}   
 </style>
</head>
<body>
<div class='title'>
<label>TOKOBUKU</label>
<p>The right book will always keep you company</p>
</div>
    <div id="menu">
                 
                  <ul>
                         <li><a href=searchbox1.html>Home</a></li> 
                        <li><a href=Profile.php>Editprofile</a></li>
                        <li><a href=Myordersdisplay.php>Myorders</a></li>
                        <li><a href=ResponsesDisplay.php>Response</a></li>
                        <li><a href=Uploads.php>Uploads</a></li>
                        <li><a href=Logout.php>Logout</a></li>
                     
                  </ul>
 </div>
 <div class='tab'>
     <table border='1'>
      <tr>
          <th>orderno</th>
          <th>BuyerName</th>
           <th>Contact</th>
                  <th>Bookname</th>
                           <th>Author</th>
                        <th>Genre</th>
                      <th>Edition</th>
                      <th>Price</th>
           <th>status</th>
          </tr> 
    <?php
            include('Responses.php');
           while($row=mysqli_fetch_assoc($result))
              {       
                    $buyerid=$row['buyerid'];
                    $sql2="select * from USERS where userid='$buyerid'";
                    $result1=mysqli_query($conn,$sql2);
                    $row1=mysqli_fetch_assoc($result1);
                    echo  "<tr>";
                     echo   "<td>".$row['Refno']."</td>";
                    echo   "<td>".$row1['Firstname'].$row1['Lastname']."</td>";  
                    echo   "<td>".$row1['phone']."</td>";      
                    echo   "<td>".$row['BookName']."</td>";
                    echo   "<td>".$row['Author']."</td>";
                    echo   "<td>".$row['Genre']."</td>";
                    echo   "<td>".$row['Edition']."</td>";
                    echo   "<td>". $row['Price']."</td>";
                    echo   "<td>";
                    if($row['status']=='Pending')
                   { echo   "<select  name='category' id='list' onchange='getselectvalue()'>";
                    echo   "<option   value='Pending'>Pending</option>";
                    echo    "<option  value='Completed'>Completed</option>";
                    echo   "<option  value='Failed'>Failed</option>";
                    echo   "</td>";
                    echo  "<td><button onClick=myfun(".$row['bookid'].")>Confirm</button></td>";   
                   }else 
                    {echo  $row['status']."</td>";}
                    echo  "</tr>";
                                       
         }
       
     ?>
 </table>
</div>
</body>
<script>
      function  myfun(id)
           {    // document.write("hiii");
                 val=document.getElementById('list');
                 result = val.options[val.selectedIndex].text;
                 document.write(result);
                 window.location.href="/Intern/status.php?Bookid="+id+"&val="+result;
           }
</script>
</html>
