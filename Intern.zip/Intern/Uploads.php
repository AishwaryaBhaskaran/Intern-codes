<?php
ini_set('display_errors','1');
session_start();
$userid=$_SESSION['userid'];
$conn=new mysqli('localhost','root','akshara08','Intern');
$sql="select * from books1 where sellerid='$userid'";
$result=mysqli_query($conn,$sql);
?>
<!DOCTYPE html>
<html>
<head>
 <style>
      
          img { height:100px;
            width:100px;
            padding:10px;
           }
            html,body{
                             width:100%;
                             height:100%;
                             
                             background-repeat:no-repeat;                  
                    } 
             
          #menu 
                {
                   position:absolute;
                   top:250px;
                   height:85%;
                   width:300px;
                    left:-5px;
                    z-index:99;
                     background-color:#B23850;
                    transition:all 500ms linear;
                }  
              #menu ul li
                {    
                      list-style-type: none;
                      font-size:25px;
                      padding:10px;
                      margin:30px 5px;
                      border-bottom:1px solid white;
                }
              .title{
                background-color:#1A1A1D;
                height:250px;
                width:100%;
                font-family: "Lobster", serif; 
                position:absolute; 
                top:0%;     
                left:0%;  
          }
         .title label{
              position:absolute; 
              font-size:50px;
              color:#E3E2DF;
              top:30%;   
              left:3%;
         }
         .title p{
               position:absolute; 
              color:#E3E2DF;
              top:45%;
              left:4%;
         }
                           table, td, th {  
  border: 1px solid #ddd;
  text-align: left;
}

table {
  border-collapse: collapse;
  width: 60%;

}
                 th, td {
                     padding: 5px;
                     text-align: left; 
                }
              a { 
             text-decoration:none;
             color:white;
        }
     a:hover {
        color:#d8d8d8;
      }
     .bookspace {
             
             position:relative;
             left:20%;
             top:250px;
        }
 </style>
</head>
<body>
<div class='title'>
<label>TOKOBUKU</label>
<p>The right book will always keep you company</p>
</div>
    <div id="menu">
                 
                  <ul>
                         <li><a href=searchbox1.php>Home</a></li> 
                        <li><a href=Profile.php>Editprofile</a></li>
                        <li><a href=Myordersdisplay.php>Myorders</a></li>
                        <li><a href=ResponsesDisplay.php>Response</a></li>
                        <li><a href=Uploads.php>Uploads</a></li>
                        <li><a href=Logout.php>Logout</a></li>
                     
                  </ul>
 </div>
<div class="bookspace">
  <table border='1'>
      <tr>
                  <th>Bookimage</th>
                  <th>Bookname</th>
                           <th>Author</th>
                        <th>Genre</th>
                      <th>Edition</th>
                      <th>Price</th>
          </tr> 
<?php
while($row=mysqli_fetch_assoc($result))
{       
         
         $Bookid=$row['Bookid'];
        $sql1="select Image from bookimage where Bookid='$Bookid'";
        $result1=mysqli_query($conn,$sql1);    
        $row1=mysqli_fetch_assoc($result1);
        $image=$row1['Image'];
        echo "<tr>";
        echo  "<td><img src='http://".$_SERVER['SERVER_NAME']. "/images/".$row1['Image']. "'/></td>";
        $bookid=$row['Bookid'];     
        $BookName=$row['Bookname'];
        echo "<td>" .$BookName ."</td>";
        $Author=$row['Author'];
        echo  "<td>".$Author."</td>";
        $Genre=$row['Genre'];
        echo  "<td>".$Genre."</td>";
        $Edition=$row['Edition'];
        echo  "<td>".$Edition."</td>";
        $Price=$row['Price'];   
        echo  "<td>".$Price."</td>"; 
       echo  "<td><button onClick=myfun(".$bookid.")>Edit</button></td>";
        echo "</tr>";
}
?>

</table>
<button onClick=myfun1()>UPLOAD</button>
</div>
</body>
<script>
         function myfun(id)
             {
                  window.location.href="/Intern/Editbooks.php?Bookid="+id;
             }
        function myfun1()
             {
                  window.location.href="/Intern/brandNew.php/";
             }
</script>
</html>
