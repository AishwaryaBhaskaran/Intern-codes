<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
     <link rel="stylesheet" href="style2.css"><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lobster">
      <script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
       <script> 
       function getBookid(id)
         {
            document.write(id);
            window.location.href="/Intern/BookDisplay.php?Bookid="+id;
         }
        </script>
      <title>Awesome Search Box</title>
      <style>
          .title{
                background-color:#1A1A1D;
                height:250px;
                width:100%;
                font-family: "Lobster", serif; 
                position:absolute; 
                top:0%;       
          }
         .title label{
              position:absolute; 
              font-size:50px;
              color:#E3E2DF;
              top:30%;   
              left:3%;
         }
         .title p{
               position:absolute; 
              color:#E3E2DF;
              top:45%;
              left:4%;
         }
         #search{
            position:relative;
            display:block;
            margin-top:5%;
        }
          #slides{
            position:relative;
            display:block;
            margin-top:10%;
            height:250px;
        }
        #php{
           position:relative;
           display:block;
           height:150;
           }
         #Signout
        {
         overflow:hidden;
        }
        #Signout a
        {
      float:right;
      display:block;
      color:white;
      text-align:center;
      padding:14px 16px; ;
      }
       #Signout a:hover
       {
       background-color:#ddd;
       color:black;
       }
       * {
  box-sizing: border-box;
}

.text{
    width:100%;
   
   display:inline-block;
   
}


table {
  border-collapse: collapse;
  width: 100%;
    position:relative;
    left:30%;top:200px;
}
                 th, td {
                   
                     text-align: left; 
                     color:white;
                         
                   
                }

 .cont {
             width:250px;
             float:left;
            display: flexbox;
       }
   </style>
   </head>
<body>
<div class='title'>
<label>TOKOBUKU</label>
<p>The right book will always keep you company</p>
</div>
<div id="Signout">
<?php
session_start();
if($_SESSION['userid'])
{echo "<a href='Logout.php'>LOGOUT</a>";}
?>

<div class="container">
<div class="topnav">
<a href=brandNew.php>SELL</button>
<a href="searchbox1.php">HOME</a>
<?php
session_start();
if(empty($_SESSION['userid']))
{ echo "<a href='welcome.php'>SIGNUP/LOGIN</a>";}
else { echo "<a href='Profile.php'>View Profile</a>"; }
?>
</div>
</div>
</div>
<?php
$con=new mysqli("localhost","root","akshara08","Intern");
if(mysqli_connect_errno())
{
echo "Failed to connect to mysql:".mysqli_connect_error();
}
$stmt="Select *from books1";
$result=mysqli_query($con,$stmt);
if(!$result)
{
echo "NO result";
}
else
{
echo "<div class='text'>";
echo "<table>";
while ($row = mysqli_fetch_array($result))
{

$stmt1="Select Image from bookimage Where Bookid='".$row['Bookid']."' ";
$res=mysqli_query($con,$stmt1);
$row1=mysqli_fetch_assoc($res);
echo "<tr>";
echo "<td>";
echo "<img src='http://".$_SERVER['SERVER_NAME']. "/images/".$row1['Image']. "' width=200 height=250/>";
echo "</td>";
echo "<td>";
if($row){

echo"BookName:";
echo $row['Bookname'];
echo "<br>";
echo "Author:";
echo $row['Author'];
echo "Genre:";
echo $row['Genre'];
echo "<br>";
echo "Edition:";
echo $row['Edition'];
echo "<br>";
echo "Price:";
echo $row['Price'];
echo"<br>";
echo "Description:";
echo $row['Description'];
echo"<br>";
echo "Date of Upload:";
echo $row['DateofUpload'];
echo "<br>";
echo "<button id='btn' onclick='getBookid(".$row['Bookid'].")' value=".$row['Bookid'].">View Details</button>";
echo "</td>";
echo "</tr>";
}


else { echo "no books";}
}
}
echo "</table>";
mysqli_close($con);
?>
</div>
<div class="form.example" id="search">
  <form method="POST" action="/books.php" style="margin:auto;max-width:300px">
  <input type="text" placeholder="Search.." name="search2">
  <button name="submit" type="submit"><i class="fa fa-search"></i></button>
  </form>
</div>
</body>
</html>













