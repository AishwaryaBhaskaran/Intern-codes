<?php
session_start();
if(empty($_SESSION['userid']))
{  
       header("Location:http://localhost/Intern/welcome.php");
}
$conn=new mysqli("localhost","root","akshara08","Intern");
$sql="select ContactAddress from USERS where userid=".$_SESSION['userid'];
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html>
<head>
<title>selling</title>
<body style="background-color:powderblue;">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300|Oswald|Roboto+Mono&display=swap"
  rel="stylesheet"><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lobster">
<style>
.title{
                background-color:#1A1A1D;
                height:250px;
                width:100%;
                font-family: "Lobster", serif; 
                position:absolute; 
                top:0%;       
          }
         .title label{
              position:absolute; 
              font-size:50px;
              color:#E3E2DF;
              top:30%;   
              left:3%;
         }
         .title p{
               position:absolute; 
              color:#E3E2DF;
              top:49%;
              left:4%;
         }
       .title a{
              position:relative;
           left:88%;top:19px;
            color:white;font-family:sans-serif;
           padding:14px 16px;
        }
*{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
.bg {
  background-image: url('book.jpg');
  background-size: cover;
}

.container{
  margin-top: 50px;
display: flex;
justify-content: center;
align-items: center;
min-height: 100vh;
margin-bottom: 50px;
}

.body{
  position: relative;
 top:200px;
  width: 800px;
  height: 1270px;
  background: rgba(255, 248, 220, .8);
  border-radius: 5px;
  box-shadow:1px 15px 25px rgba(0,0,0,.5);
}

.head{
  font-family: 'Open Sans Condensed', sans-serif;
  font-size: 25px;
  letter-spacing: 3;
  margin: 10px 5px;
  text-align: center;
}

.form{
  font-family: 'Roboto Mono', monospace;
  margin: 10px 5px;
  padding: 0 5px;
  font-weight: 500;
}

.bottom{
  margin: 10px 5px;
  padding: 5px 10px;
  font-family: 'Roboto Mono', monospace;
}
.replay{
  margin: 10px 5px;
  text-align: right;
}

.btn{
  font-family: 'Roboto Mono', monospace;
  margin: 10px;
  padding: 10px;
  font-size: 20px;
  font-weight: 500;
  border: none;
  cursor: pointer;
  background: #ecf0f1;
  border-radius: 10px;
}

.btn:hover{
  background: #34495e;
  color: #ecf0f1;
}

.box{
  display: block;
  margin: 10px;
  width: 100%;
padding: 10px 0;
font-size: 16px;
color: #000;
letter-spacing: 1px;
margin-bottom:30px;
border: none;
border-bottom:1px solid #000;
outline: none;
background:transparent;
}

.link{
  text-decoration: none;
}

</style>
</head>
<body class="bg">
      <div class='title'>
<label>TOKOBUKU</label>
<p>The right book will always keep you company</p>
<a href="searchbox1.php">HOME</a>
</div>
  <div class="container">
    <div class="body">
        <h2 class="head">Book Details</h2>
        <form name="newad" method="post" enctype="multipart/form-data" action="/Intern/seller.php">
        
          <p class="form">
            <label for="Image">UPLOAD</label>
            <input type="FILE" name="profile" class="box">
          </p>
          <p class="form">
            <label for="pbook">Book Name</label>
            <input type="text" name="pbook" class="box">
          </p>
          <p class="form">
            <label for="fullname">Author Full Name</label>
            <input type="text" name="name" class="box">
          </p>
          <p class="form">
            <label for="genre">Genre</label>
            <input type="textarea" name="genre" class="box">
          </p>
          <p class="form">
            <label for="price">Edition </label>
            <input type="textarea" name="edition" class="box">
          </p>
          <p class="form">
            <label for="price">Price </label>
            <input type="textarea" name="price" class="box">
          </p>
          <p class="form">
            <label for="description">Description</label>
            <input type="textarea" name="description" class="box">
          </p>
          <p>
            <?php
            if(empty($row['ContactAddress']))
            {echo '<label for="seller">Address</label>';
            echo '<input type="textarea" name="Address"class="box">';
            }
            else {
            echo  '<label for="seller">Address</label>';
            echo  '<input type="textarea" name="Address" class="box" value="'.$row['ContactAddress'].'">';
            }
            ?>
          </p>
          <p class="bottom"> <input type="checkbox" />, I have read and provide my consent for my data to be processed for the purposes as
            mentioned in the <a class="link" dataurl="https://studyabroad.shiksha.com/shikshaHelp/ShikshaHelp/privacyPolicy"
              href="javascript:void(0);">Privacy Policy</a> and <a class="link"
              dataurl="https://studyabroad.shiksha.com/shikshaHelp/ShikshaHelp/termCondition" href="javascript:void(0);">Terms
              &amp; Conditions</a>.</p>
          <p class="bottom"> <input type="checkbox" />I agree to be contacted for service related information and promotional purposes.</p>
          <div class='field replay'>
            <script src="https://www.google.com/recaptcha/api.js" async defer></script>
            <div data-sitekey="6LcFA8YUAAAAAKWdhK0V4W374DMdvIsiuekZ38ca" class="g-recaptcha " display="{:theme=>" white}></div>
            <noscript>
              <div class="replay">
                <div style="width: 302px; height: 422px; position: relative;">
                  <div style="width: 302px; height: 422px; position: absolute;">
                    <iframe src="https://www.google.com/recaptcha/api/fallback?k=6LcFA8YUAAAAAKWdhK0V4W374DMdvIsiuekZ38ca"
                      frameborder="0" scrolling="no" style="width: 302px; height:422px; border-style: none;">
                      title="ReCAPTCHA"
                    </iframe>
                  </div>
        
                </div>
                <div style="width: 300px; height: 60px; border-style: none;
                                    bottom: 12px; left: 25px; margin: 0px; padding: 0px; right: 25px;
                                    background:#f9f9f9; border: 1px solid  #c1c1c1; border-radius: 3px;">
                  <textarea id="g-recaptcha-response" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px; height: 40px; border: 1px solid #c1c1c1;
                                      margin: 10px 25px; padding: 0px; resize: none;" value="">
                    </textarea>
                </div>
              </div>
            </noscript>
        
          </div>
          <input type="submit" value="submit" class="btn">
        </form>
        </fieldset>
        
        </form>
    </div>
   
  </div>

</body>
</head>
