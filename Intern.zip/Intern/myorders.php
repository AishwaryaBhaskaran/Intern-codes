
<?php
ini_set('display_errors','1');
session_start();
$userid=$_SESSION['userid'];
$Message=" ";
$conn=new mysqli('localhost','root','akshara08','Intern');
$sql="select * from orders where buyerid='$userid'  ORDER BY orderid DESC ";
 $result=mysqli_query($conn,$sql);
 if(mysqli_num_rows($result)==0)       
   { 
        $message="no books found";   
   }
?>

