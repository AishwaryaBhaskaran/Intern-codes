<?php
session_start();
if(empty($_SESSION['userid']))
{
    header("Location:http://localhost/Intern/welcome.php");
}
else {
$Bookid=$_SESSION['bookid'];
$sellerid=$_SESSION['sellerid'];
$Requesteddate = date('Y-m-d'); 
$userid=$_SESSION['userid'];
$conn=new mysqli("localhost","root","akshara08","Intern");
$sql1="select Bookname,Author,Genre,Edition,Price from books1 where Bookid='$Bookid'";
$result1=mysqli_query($conn,$sql1);

mysqli_num_rows($result1);
$row=mysqli_fetch_assoc($result1);
$sql="insert into orders(buyerid,bookid,Bookname,sellerid,Author,Genre,Edition,Price,status,Refno)values('$userid','$Bookid','".$row['Bookname']."','$sellerid','".$row['Author']."','".$row['Genre']."','".$row['Edition']."','".$row['Price']."','Pending','ORD00')";
$result=mysqli_query($conn,$sql);
$lastid=mysqli_insert_id($conn);
echo '======>'. $lastid;
$ref='ORD00'.$lastid;
echo "<br>referecnce Id===>". $ref;
echo '"===============>'. $sql2="UPDATE orders SET Refno='".$ref."' WHERE orderid=".$lastid;
 $result2=mysqli_query($conn,$sql2);
echo "<pre>";print_r($result2);echo "<pre>";print_r($sql2);


if($result)
{
echo "res";
}
$_SERVER['REQUEST_URI']="http://localhost/Intern/Myordersdisplay.php";
 header('Location: '.$_SERVER['REQUEST_URI']);
$conn->close();
}
?>                                                                                                                                                                                          
