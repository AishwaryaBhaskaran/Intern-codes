<!DOCTYPE html>
<html>
  <head>
     <meta charset="UTF-8">
     <link rel="stylesheet" href="style2.css"><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lobster">
      <script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>
      <title>Awesome Search Box</title>
      <style>
           .title{
                background-color:#1A1A1D;
                height:250px;
                width:100%;
                font-family: "Lobster", serif; 
                position:absolute; 
                top:0%;       
          }
         .title label{
              position:absolute; 
              font-size:50px;
              color:#E3E2DF;
              top:30%;   
              left:3%;
         }
         .title p{
               position:absolute; 
              color:#E3E2DF;
              top:45%;
              left:4%;
         }
         #search,input[type='text']{
                    position:absolute;
                    top:10%;left:35%;
                    width: 350px;
                    height: 40px;
                    border-radius: 40px;
                    box-shadow: 0 6px 8px rgba(0, 0, 0, 0.15);
        }
                 button{
                    position:relative;
                    top:5px;left:409px;
                     height:40px;width:40px;
                    border-radius:50%;
                    background-color:#E3AFBC;
                    box-shadow: 0 6px 8px rgba(0, 0, 0, 0.15);
        }
           
           .note p{
                   
                   color:white;
                   position:relative;
                   top:300px;
                   font-family:sans-seriff BOLD;
                   font-size:40px;
                   text-align:centre;
           }
          #slides {
            position:relative;   
            display:block;
            margin-top:22%;
            height:400px;
        }
        img
          {
            padding:4px;
            height:300px;
            width:300px;
         }
        #Signout a
        {position:relative;
           left:83%;top:19px;
          color:white;
           padding:14px 16px; 
      }
       #Signout a:hover
       {
       background-color:#ddd;
       color:black;
       }
      </style>
   </head>
   <body>
<div class='title'>
<label>TOKOBUKU</label>
<p>The right book will always keep you company</p>
</div>
<div id="Signout">
<a href="books2.php">VIEW BOOKS</a>
<a href=brandNew.php>SELL</a>

<?php
session_start();
if($_SESSION['userid'])
{echo "<a href='Logout.php'>LOGOUT</a>";}
?>
</div>
<div class="container">
<div class="topnav">

<a href="searchbox1.php">HOME</a>
<?php
session_start();
if(empty($_SESSION['userid']))
{ echo "<a href='welcome.php'>SIGNUP/LOGIN</a>";}
else { echo "<a href='Profile.php'>View Profile</a>"; }
?>
</div>
</div>

<div class="form.example" id="search">
  <form method="POST" action="/Intern/books.php" style="margin:auto;max-width:300px">
  <input type="text" placeholder="Search by bookname/Author" name="search2">
  <button name="submit" type="submit"><i class="fa fa-search"></i></button>
  </form>
</div>
<div class="note">
  <p>Don't miss the new uploads!</p>
</div>
<div id="slides">
<marquee behavior="slide" direction="left" marquee-play-count:infinite>
<?php
$conn=new mysqli("localhost","root","akshara08","Intern");
$res="select * from bookimage";
$res1=mysqli_query($conn,$res);
while($a=mysqli_fetch_array($res1))
{       
        echo   "<a href='/Intern/BookDisplay.php?Bookid=".$a['Bookid']."'><img src='http://".$_SERVER['SERVER_NAME']. "/images/".$a['Image']. "'width=160px height=150px></a>";
}
$conn->close();
?>
</marquee>
</div>

</body>
</html>
