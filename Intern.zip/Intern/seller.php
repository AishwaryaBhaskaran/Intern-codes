<?php 
$conn = new mysqli("localhost","root","akshara08","Intern");
session_start();
echo  "<pre>";print_r($_POST);print_r($_FILES);
$sellerid =$_SESSION['userid'];
$profile=$_FILES['profile']['name'];
$bname = $_POST['pbook'];
$aname = $_POST['name'];
$genre = $_POST['genre'];
$price = $_POST['price'];
$edition = $_POST['edition'];
$description = $_POST['description'];
$address=$_POST['Address'];
 $sql = "INSERT INTO books1(sellerid,Bookname, Author, Genre, Edition, Price, Description) VALUES ('$sellerid','$bname','$aname','$genre','$edition','$price','$description')";
echo $sql;
 $result=mysqli_query($conn,$sql);
$id=mysqli_insert_id($conn);echo $id;
     $target='/var/www/html/images/'.basename($profile);
     echo 'upload status====>'. $upload=move_uploaded_file($_FILES['profile']['tmp_name'], $target);

echo "<pre>";print_r($_POST);
$sql1="INSERT INTO bookimage(Image,Bookid)values('$profile','$id')";echo $sql1;
$result1=mysqli_query($conn,$sql1);
 if(!empty($address)) {
      $sql2="UPDATE USERS SET ContactAddress='$address' WHERE userid='$sellerid'";echo $sql2;
      $result2=mysqli_query($conn,$sql2);
  }
 if($result) {
      echo "success";
  }
$_SERVER['REQUEST_URI']="http://localhost/Intern/Uploads.php";
 header('Location: '.$_SERVER['REQUEST_URI']);
?>

