  <?php
   $conn=new mysqli('localhost','root','akshara08','Intern');
   $bookid=$_GET['Bookid'];
   $sql="select * from orders where bookid='$bookid'";
   $result=mysqli_query($conn,$sql);
   $row=mysqli_fetch_assoc($result);
   $sql1="select Image from bookimage where Bookid='$bookid'"; 
   $result1=mysqli_query($conn,$sql1);
   $row1=mysqli_fetch_assoc($result1);
  $sql2="select * from USERS where userid=".$row['sellerid'];
  $result2=mysqli_query($conn,$sql2);
  $row2=mysqli_fetch_assoc($result2);
?>
<!DOCTYPE html>
<html>
<head>
     <style>
                               html,body{
                             width:100%;
                             height:100%;
                             
                             background-repeat:no-repeat;                  
                    } 
          .title{
                background-color:#1A1A1D;
                height:250px;
                width:100%;
                font-family: "Lobster", serif; 
                position:absolute; 
                top:0%;     
                left:0%;  
          }
         .title label{
              position:absolute; 
              font-size:50px;
              color:#E3E2DF;
              top:30%;   
              left:3%;
         }
         .title p{
               position:absolute; 
              color:#E3E2DF;
              top:45%;
              left:4%;
         }
             #menu 
                {
                   position:absolute;
                   top:250px;
                   height:85%;
                   width:300px;
                    left:-5px;
                    z-index:99;
                     background-color:#B23850;
                    transition:all 500ms linear;
                }  
              
          
              #menu ul li
                {    
                      list-style-type: none;
                      font-size:25px;
                      padding:10px;
                      margin:30px 5px;
                      border-bottom:1px solid white;
                }
              a { 
             text-decoration:none;
             color:white;
        }
     a:hover {
        color:#d8d8d8;
      }
           .bookspace {
             width:700px;
             position:relative;
             left:30%;
            top:250px;
        }
          .bookdet{
                position:absolute;top:1%;
               left:52%;
       }
            img{ 
                      width:350px;
                     height:450px;
                }
     </style>
</head>
 <body>
<div class='title'>
<label>TOKOBUKU</label>
<p>The right book will always keep you company</p>
</div>
       <div id="menu">
                 
                  <ul> 
                         <li><a href=searchbox1.php>Home</a></li>
                        <li><a href=Profile.php>Editprofile</a></li>
                        <li><a href=Myordersdisplay.php>Myorders</a></li>
                        <li><a href=ResponsesDisplay.php>Response</a></li>
                        <li><a href=Uploads.php>Uploads</a></li>
                        <li><a href=Logout.php>Logout</a></li>
                     
                  </ul>
 </div>
  <div class='bookspace'>
  <?php 
    echo "<div>";
   $Image=$row1['Image'];
   echo "<img src='http://".$_SERVER['SERVER_NAME']. "/images/".$row1['Image']. "'/>";
   echo  "</div>";
   echo  "<div class=bookdet>";
    echo "<label>BookName:</label>";
    $Bookname=$row['BookName'];
    echo   $Bookname;echo "<br><br>";
     echo "<label>Author:</label>";
   $Author=$row['Author'];
    echo   $Author; echo "<br><br>";
       echo "<label>Genre:</label>";
   $Genre=$row['Genre'];
    echo   $Genre; echo "<br><br>";
    echo "<label>Edition:</label>";
   $Edition=$row['Edition'];
    echo   $Edition; echo "<br><br>";
    echo "<label>Price:</label>";
   $Price=$row['Price'];
    echo   $Price; echo "<br><br>";
    echo "<label>Status:</label>";
    $status=$row['status'];
   echo  $status;  echo "<br><br>";
   echo  "</div>";
   echo  "<hr>";
   echo  "<label>SELLER DETAILS</label>";   
   echo  "<br>";
   echo "<label>Name:</label>";
   echo  $row2['Firstname'].$row2['Lastname'];
   echo  "<br>";
   echo "<label>Phone:</label>";
   echo $row2['phone'];
   echo  "<br>";
   echo "<label>Address:</label>";
   echo $row2['ContactAddress'];
 ?>
</div>
 </body>
 </html>
