<?php
ini_set('display_errors','1');
session_start();
$Warning="";
$Userprofile=$Firstname=$Lastname=$email=$userpassword=$usercontact="";
if(isset($_POST['submit']))
 {      echo "<pre>";print_r($_POST);print_r($_FILES);
         $Firstname=$_POST['firstname'];
         $Lastname=$_POST['lastname']; 
         $email=$_POST['useremail'];
         $password=$_POST['userpassword'];
         $contact=$_POST['usercontact'];
         $userprofile=$_FILES['profile']['name'];
  }

 $conn=new mysqli("localhost","root","akshara08","Intern");

           $emailcheck="select userid from USERS where useremail='$email'";echo $emailcheck;
           $checkresult=mysqli_query($conn,$emailcheck);
   
            if(($count=mysqli_num_rows($checkresult))>0) 
                { $Warning="!Account already exists";
                echo "<script type='text/javascript'>alert('$Warning');window.location='http://localhost/Intern/welcome.php/';</script>";
                 }
            else
                {
                    $hash=password_hash($password,PASSWORD_DEFAULT);
                    $sql="insert into USERS(Firstname,Lastname,useremail,userpassword,phone)values('$Firstname','$Lastname','$email','$hash','$contact')";echo $sql;
                    $result=mysqli_query($conn,$sql);
                  $sql1="select userid from USERS where useremail='$email'";
                  $result1=mysqli_query($conn,$sql1);
                 $row=mysqli_fetch_assoc($result1);
    
                    $userid=$row['userid'];
                    $_SESSION['userid']=$userid;
                  echo basename($userprofile);
                  $target='/var/www/html/userimages/'.basename($userprofile);
                  $upload=move_uploaded_file($_FILES['profile']['tmp_name'], $target);
                  $sql3="insert into image(image,userid)values('$userprofile','$userid')";echo $sql3;
                  $result2=mysqli_query($conn,$sql3);         
                  header("Location:http://localhost/Intern/Profile.php");
     }


?>
