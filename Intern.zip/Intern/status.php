<?php
 echo  "<pre>";echo print_r($_GET);
 $conn=new mysqli('localhost','root','akshara08','Intern');
 $sql1="UPDATE orders SET  status='".$_GET['val']."' where Bookid=".$_GET['Bookid'];echo $sql1;
 $result=mysqli_query($conn,$sql1);
header("Location:http://localhost/Intern/ResponsesDisplay.php");
?>
