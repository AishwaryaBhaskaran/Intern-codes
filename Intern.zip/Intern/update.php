<?php
session_start();
$Firstname=$Lastname=$phone=$image=" ";
$userid=$_SESSION['userid'];

if(isset($_POST['update']))
{  
     echo "<pre>";print_r($_FILES);
    
    $Firstname=$_POST['firstname'];
    $Lastname=$_POST['Lastname'];
    $phone=$_POST['phone'];
   $image=$_FILES['profile']['name'];
}
$conn=new mysqli('localhost','root','akshara08','Intern');
 $target='/var/www/html/userimages/'.basename($image);
echo $target;
$upload=move_uploaded_file($_FILES['profile']['tmp_name'], $target);
echo "<pre>".print_r($upload);
if($conn)
{
$sql="UPDATE USERS SET Firstname='$Firstname', Lastname='$Lastname' , phone='$phone' where userid='$userid'";
$result=mysqli_query($conn,$sql);
if(!empty($image))
{
echo $sql1="UPDATE image SET image='".$image."' where userid='$userid'";
echo $res=mysqli_query($conn,$sql1);
}
if(!$res)
{
    echo "image not updated";
}
if($result)
{
   echo "updated";
}

else
{
   echo "error";
}
}
else
{
       echo "not connected";
}
$_SERVER['REQUEST_URI']="http://localhost/Intern/Profile.php";
 header('Location: '.$_SERVER['REQUEST_URI']);
?>
