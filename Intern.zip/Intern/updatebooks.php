<?php
session_start();
$Image=$Bookname=$Author=$Genre=$Edition=$Price=$Desc=" ";
$bookid=$_SESSION['bookid'];

if(isset($_POST['update']))
{  
     echo "<pre>";print_r($_FILES);print_r($_POST);
         $Image=$_FILES['profile']['name'];
        $Bookname=$_POST['Bookname'];
        $Author=$_POST['Author'];
        $Genre=$_POST['Genre'];
        $Edition=$_POST['Edition'];
       $Price=$_POST['Price'];
       $Desc=$_POST['Desc'];

}
$conn=new mysqli('localhost','root','akshara08','Intern');
 $target='/var/www/html/Intern/images/'.basename($Image);
echo $target;
$upload=move_uploaded_file($_FILES['profile']['tmp_name'], $target);
echo "<pre>".print_r($upload);
if($conn)
{
$sql="UPDATE books1 SET Bookname='$Bookname', Author='$Author' , Genre='$Genre' , Edition='$Edition' , Price='$Price' , Description='$Desc'  where Bookid='$bookid'";
$result=mysqli_query($conn,$sql);echo $sql;
if(!empty($Image))
{echo $sql1="UPDATE bookimage SET Image='".$Image."' where Bookid='$bookid'";
echo $res=mysqli_query($conn,$sql1);
}
if(!$res)
{
    echo "image not updated";
}
if($result)
{
   echo "updated";
}

else
{
   echo "error";
}
}
else
{
       echo "not connected";
}
$_SERVER['REQUEST_URI']="http://localhost/Intern/Uploads.php";
 header('Location: '.$_SERVER['REQUEST_URI']);
?>
