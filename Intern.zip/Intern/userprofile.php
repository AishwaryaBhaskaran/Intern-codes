
<?php
session_start();
$userid=$_SESSION['userid'];
$Firstname=$Lastname=$useremail=$userpassword=$phone=$image="";
$conn=new mysqli('localhost','root','akshara08','Intern');
if($conn)
{
     $stmt="select Firstname,Lastname,useremail,userpassword,phone from USERS where userid='$userid'";
     $result=mysqli_query($conn,$stmt);
     if($result)
       {
            $row=mysqli_fetch_assoc($result);
            $Firstname=$row['Firstname'];
            $Lastname=$row['Lastname'];
            $useremail=$row['useremail'];
            $userpassword=$row['userpassword'];
            $phone=$row['phone']; 
       }
     else
       {
            echo "error";
       }   
      $stmt1="select image from image where  userid='$userid'";
      $result2=mysqli_query($conn,$stmt1);
      if($result2)
       {
           $row1=mysqli_fetch_assoc($result2);
           $image=$row1['image'];
         
       }
     else 
       { 
             echo "error image";
       }
}    
else
{
     echo "connection error";
}
?>

