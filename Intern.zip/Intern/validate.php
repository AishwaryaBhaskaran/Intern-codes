<?php
ini_set('display_errors','1');
echo "hii";
session_start();

$email=$password="";
if(isset($_POST['submit']))
{$email=$_POST['useremail'];
$password=$_POST['userpassword'];echo $email;
}
 $host="localhost";
 $dbusername="root";
 $dbpassword="akshara08";
 $database="Intern";
 $conn=new mysqli($host,$dbusername,$dbpassword,$database);
    $select="select userid,userpassword from USERS where useremail='$email'";
    $result=mysqli_query($conn,$select);
     $row=mysqli_fetch_assoc($result);
        
         if(password_verify($password,$row['userpassword']))
               {echo "login successful";
             
            $_SESSION['userid']=$row['userid'];
            header("Location:http://localhost/Intern/Profile.php");
            $conn->close();
                } 
                else
               {echo "sorry wrong password";}

  
?>
