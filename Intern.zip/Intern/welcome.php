<?php
session_start();
if($_SESSION['userid'])
{
      header("Location:http://localhost/Intern/Profile.php");exit;
}
?>
<!Doctype html>
<html>
      <head> 
                               <link   href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.css" 
  rel="stylesheet"  type='text/css'/><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lobster">
           <style> 
 
                    html,body{
                             width:100%;
                             height:100%;
                             background-color:#1f2833;
                             background-repeat:no-repeat;    
                    } 
                 .title{
                background-color:#1A1A1D;
                height:250px;
                width:100%;
                font-family: "Lobster", serif; 
                position:absolute; 
                top:0%;left:0%;    
          }
         .title label{
              position:absolute; 
              font-size:50px;
              color:#E3E2DF;
              top:30%;   
              left:3%;
         }
         .title p{
               position:absolute; 
              color:#E3E2DF;
              top:45%;
              left:4%;
         }
                     .background{
                             
                             height:50%;
                             width:65%;
                             
                             background-color:#B23850;
                             align-content:center;
                             position:absolute;
                             top:50%;
                             left:17%;
                             right:30%;
                             bottom:30%;
                     }
                  
                        fieldset {
                               border-radius:5px;
                               padding:15px 35px 15px 35px;
                               position:relative;
                               top:-150px;
                               left:170px;
                               background-color:#265077;
                        }
                       .field2 fieldset {
                               background-color:#644e5b;      
                        }
                       .field2 p{
                               color:white;
                        }
                    .signin,input{
                            display:block;
                            margin: 0;
                            color: inherit;
                           width:350px;
                            height:40px;
                           border:1px black;!important
                           border-radius: 0.4rem;
                           display:inline-block;
                    }
                    input[type="text"] ,input[type="tel"],input[type="password"],select{
                             display:block;
                             border-bottom:1px black solid;
                             font-family:sans-seriff;
                             font-size:20px; 
                    }
                   .image{
                             display:block;
                             width:190px;
                             height:190px;
                             border:1px ;
                             border-radius:50%;
                             background-image:url("avataricon.png");
                             margin-left:auto;
                             margin-right:auto;
                             font-size:19px;
                   }
                 input[type="file"]
                       {
                              display:none;                         
                       }
                  p{
                        text-align:center;
                        font-size:30px;
                  }
                 button{
                         display:block;
                         margin-left:auto;
                         margin-right:auto;
                         background-color:#ee68cd;
                         color:white;
                         font-size:20px;
                         border:1px black;
                         border-radius:2px;
                         box-shadow:2px 2px 2px 2px;
                         padding:5px;
                    }
                  .field2{
                       position:absolute;
                       top:73px;
                       left:440px;
                       
                    }
              .fields p{font-size:10px;color:white;}
              .fields  i {
                     position:relative;
                     top:-4%;
                     left:-5%;
                 }
             a{float:right;
      display:block;
      color:white;
      text-align:center;
      padding:14px 16px;}
           </style>
      </head>
<body>
    <div class='title'>
<label>TOKOBUKU</label>
<p>The right book will always keep you company</p>
</div>
   <a href="searchbox1.php">HOME</a>
   <div  class="background">     
     <div class="signin" id="card">
               <div class="field1">
               <fieldset>
               <p>SIGNUP</p>
              <form action="/Intern/signin.php" method="POST" enctype="multipart/form-data">
               <label class="image">
               <input type="file" name="profile" />
               </label><br><br> 
               <div class="fields">
              <input type="text" name="firstname" placeholder="Firstname" required/><br><br>
              <input type="text" name="lastname" placeholder="Lastname" required/><br><br>
              <input  type="text" name="useremail" placeholder="Email" required/><br><br>
              <input type="password" name="userpassword" id="password-field" placeholder="Password" required/>
              <i id="pass-status" class="fa fa-eye" aria-hidden="true" onClick="viewPassword()"></i>
              <p>*password must be atleast 8 characters long,should have atleast one number,character.</p>
              <input type="tel" name="usercontact" placeholder="Phone" required/><br><br>
              </div>
              <button class="submit"  name="submit"  value="signup" >SIGNUP</button>
              </form>
             </fieldset>
              <?php
                  if($Warning)
                   { echo "<label>".$Warning."</label>"; }
               ?>
              <div>
            <div class="field2">
           <fieldset> 
             <form action="/Intern/validate.php" method="POST">
               <p>LOGIN</p>
              <img src="avataricon.png" class="image"/><br><br><br>
             <input  type="text" name="useremail" placeholder="email" required/><br><br>
             <input type="password" name="userpassword" id="password" placeholder="password" required/>
             <i id="pass" class="fa fa-eye" aria-hidden="true" onClick="viewpassword()"></i><br><br>
             <button class="submit"  name="submit"   value="login">LOGIN</button><br><br>
             </form>
            </fieldset>
             </div>
  </div>
   
  </div>
<script>
function viewPassword(){
    var passwordInput = document.getElementById('password-field');
    var passStatus = document.getElementById('pass-status');	
  if (passwordInput.type == 'password')
  {
    passwordInput.type='text';
    passStatus.className='fa fa-eye-slash';
  }
  else
  {
    passwordInput.type='password';
    passStatus.className='fa fa-eye';
  }
 
}
function viewpassword(){
    var passwordInput = document.getElementById('password');
    var passStatus = document.getElementById('pass');	
  if (passwordInput.type == 'password')
  {
    passwordInput.type='text';
    passStatus.className='fa fa-eye-slash';
  }
  else
  {
    passwordInput.type='password';
    passStatus.className='fa fa-eye';
  }
 
}
</script>
</body>
</html>
